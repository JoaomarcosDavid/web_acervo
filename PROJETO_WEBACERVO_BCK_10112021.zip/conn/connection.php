<?php


    // $con = mysqli_connect('mysql.sistemasemetodos.com','sistemasemetod43','WxVjw6uczkow','sistemasemetod43');
	//$con = mysqli_connect('mysql.sistemasemetodos.com','sistemasemetod43','WxVjw6uczkow','sistemasemetod43');


	// if($con){
    	
 	// 	// echo "connection sucessfull";

	// }else{

	// 	echo mysqli_error($con);

	// }


?>