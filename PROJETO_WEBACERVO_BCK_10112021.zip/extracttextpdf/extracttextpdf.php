
<?php
     
    $extract_pdf_url   = $_POST['extract_pdf_url'];
     
    /**
     * Exemple extract text from PDF document
     */
    //get root path
    //$rootDir = realpath(dirname( __FILE__)."/../../../");

    // Include Composer autoloader if not already done.
    include '../vendor/autoload.php';

    // Parse pdf file and build necessary objects.
    $parser = new \Smalot\PdfParser\Parser();
    $pdf    = $parser->parseFile($extract_pdf_url);

    $text = $pdf->getText();

    echo $text;
    echo PHP_EOL;
    echo PHP_EOL;

?>