  <!-- Bootstrap Js -->
  <script src="js/jquery/popper.min.js"></script>
  <script src="js/jquery/bootstrap.min.js"></script>
  <!--Todos os javascripts-->
  <?php include_once 'js/custom/custom_js.php'; ?>
  
  <!--requisicoes ajax-->
  <?php include_once 'js/custom/requisicoesAjax_js.php'; ?>

  <!--requisicoes para internas ajax-->
  <?php include_once 'js/custom/req_internas_js.php'; ?>

  </body>
</html>

	


